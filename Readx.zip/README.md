# Readx
It's a graduation project that's aims to making a system to our facult library.
